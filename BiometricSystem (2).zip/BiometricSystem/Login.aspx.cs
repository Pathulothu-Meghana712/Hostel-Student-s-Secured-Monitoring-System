﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BiometricSystem
{
    public partial class Login : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();

            if (ddlrole.SelectedItem.Text == "HostelManager")
            {
                SqlCommand cmd = new SqlCommand("Select UserName,Password from Roles  where UserName='" + txtuname.Text + "' and Password='" + txtpwd.Text + "' ", con);
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                { 
                    Session["Wname"] = txtuname.Text;
                    Session["WRole"] = sdr[0].ToString();
                    Response.Redirect("Warden/Add_Student.aspx");
                }
                else
                {
                    ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid UserName or Password')</script>");
                }
            }
            //if (ddlrole.SelectedItem.Text == "Cse Hod")
            //{
            //    SqlCommand cmd = new SqlCommand("Select UserName,Password from Roles where UserName='" + txtuname.Text + "' and Password='" + txtpwd.Text + "' ", con);
            //    SqlDataReader sdr = cmd.ExecuteReader();
            //    if (sdr.Read())
            //    {
            //        Session["Hname"] =txtuname.Text;
            //        Session["HRole"] = sdr[0].ToString();
            //        Response.Redirect("Hod/Home.aspx");
            //    }
            //    else
            //    {
            //        ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid UserName or Password')</script>");
            //    }
            //}
           
            if (ddlrole.SelectedItem.Text == "Principal")
            {
                SqlCommand cmd = new SqlCommand("Select UserName,Password from Roles where UserName='" + txtuname.Text + "' and Password='" + txtpwd.Text + "' ", con);
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    Session["Pname"] = txtuname.Text;
                    Session["pwd"] = txtpwd.Text;
                    Session["PRole"] = sdr[0].ToString();
                    Response.Redirect("Principal/View_Student.aspx");
                }
                else
                {
                    ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid UserName or Password')</script>");
                }
            }
        }
    }
}