﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace BiometricSystem.Admin
{
    public partial class ViewRoles : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) {
                BindRoles();
            }
        }

        private void BindRoles()
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from Roles", con);
            SqlDataAdapter sdr = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sdr.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }

        protected void GridView1_RowUpdating(object sender, System.Web.UI.WebControls.GridViewUpdateEventArgs e)
        {
            TextBox fname = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Textbox2");
            TextBox lname = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Textbox3");
            TextBox fullname = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Textbox4");
            TextBox Uname = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Textbox5");
            Label role = (Label)GridView1.Rows[e.RowIndex].FindControl("Label7");
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update Roles set FirstName='" + fname.Text + "',LastName='" + lname.Text + "',FullName='" + fullname.Text + "',UserName='" + Uname.Text + "' where Role='" + role.Text + "'";
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            con.Close();
          
            GridView1.EditIndex = -1;
            BindRoles();
        }

        protected void GridView1_RowEditing(object sender, System.Web.UI.WebControls.GridViewEditEventArgs e)
        {
            GridView1.EditRowStyle.ForeColor = System.Drawing.Color.Blue;
            GridView1.EditIndex = e.NewEditIndex;
            BindRoles();
        }

        protected void GridView1_RowDeleting(object sender, System.Web.UI.WebControls.GridViewDeleteEventArgs e)
        {
            Label role = (Label)GridView1.Rows[e.RowIndex].FindControl("Label7");
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from  Roles where Role='" + role.Text + "'";
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            con.Close();
            BindRoles();
        }

        protected void GridView1_RowCancelingEdit(object sender, System.Web.UI.WebControls.GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            BindRoles();
        }
    }
}
