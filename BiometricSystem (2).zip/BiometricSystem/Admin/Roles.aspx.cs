﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BiometricSystem.Admin
{
    public partial class Roles : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetRoles();
            }
          
        }
        private void GetRoles()
        {
            List<string> ls = new List<string>();
            ls.Add("HostelManager");
            ls.Add("DeputyWarden CME");
            ls.Add("DeputyWarden ECE");
            ls.Add("DeputyWarden AEI");
            ls.Add("Principal");

            ddlrole.Items.Clear();
            ddlrole.Items.Insert(0, "--Select--");
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from Roles", con);
            SqlDataReader sdr;
            sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                ls.Remove(sdr[6].ToString());
            }
            foreach (string s in ls)
            {
                ddlrole.Items.Add(s);
            }
        }

            protected void btnSubmit_Click(object sender, EventArgs e)
            {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Roles values('" + txtfname.Text + "','" + txtlname.Text + "','" + txtflname.Text + "','" + txtuname.Text + "','" + txtpwd.Text + "','" + ddlrole.SelectedItem.Text + "') ", con);
            int i = cmd.ExecuteNonQuery();
            if (i>0)
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Added SuccessFully')</script>");
                txtfname.Text = txtlname.Text = txtflname.Text = txtuname.Text = txtpwd.Text = "";
                ddlrole.ClearSelection();

            }
        }
    }
}