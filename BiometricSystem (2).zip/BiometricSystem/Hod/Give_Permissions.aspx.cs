﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BiometricSystem.HOD
{
    public partial class GivePermissions : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);

        protected void Page_Load(object sender, EventArgs e)
        {
            BindThumbData();
        }

        private void BindThumbData()
        {

            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("select Student.HallTicketNo,Student.Name,Student.MobileNo,Thumb.Trelation,Thumb.Thumb,Thumb.Date,Thumb.Status from Student inner join Thumb on Student.HallTicketNo=Thumb.HallTicketNo", con);
            SqlDataAdapter sdr = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sdr.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            LinkButton btnEdit = (LinkButton)sender;
            GridViewRow Grow = (GridViewRow)btnEdit.NamingContainer;
            Label htno = (Label)Grow.FindControl("Label1");
            Session["htno"] = htno.Text;
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

            con.Open();
            SqlCommand cmd1 = new SqlCommand("update Thumb set Status = 'Accepted' where HallTicketNo = '" + htno.Text + "'", con);
            int i = cmd1.ExecuteNonQuery();
            if (i > 0)
            {

            }
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            LinkButton btnEdit = (LinkButton)sender;
            GridViewRow Grow = (GridViewRow)btnEdit.NamingContainer;
            Label htno = (Label)Grow.FindControl("Label1");
            Session["htno"] = htno.Text;
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

            con.Open();
            SqlCommand cmd1 = new SqlCommand("update Thumb set Status = 'Rejected' where HallTicketNo = '" + htno.Text + "'", con);
            int i = cmd1.ExecuteNonQuery();
            if (i > 0)
            {

            }
        }
    }
}