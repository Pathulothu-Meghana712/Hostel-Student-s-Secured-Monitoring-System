﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BiometricSystem.PRINCIPAL
{
    public partial class ViewTimings : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindThumbData();
            }
          
        }

        private void BindThumbData()
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("select Student.HallTicketNo,Student.Name,Student.MobileNo,Thumb.Trelation,Thumb.Thumb,Thumb.Date from Student inner join Thumb on Student.HallTicketNo=Thumb.HallTicketNo", con);
            SqlDataAdapter sdr = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sdr.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
    }
}