﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BiometricSystem.Warden
{
    public partial class Permission : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                btnThumb.Visible = false;
                txthtno.Text = Session["htno"].ToString();
                GetRelation();
            }

        }

        private void GetRelation()
        {
            List<string> ls = new List<string>();
            ls.Add("Father");
            ls.Add("Mother");
            ls.Add("LocalGuardian");
            DropDownList1.Items.Clear();
            DropDownList1.Items.Insert(0, "--Select--");
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from Thumb where HallTicketNo='" + txthtno.Text + "'", con);
            SqlDataReader sdr;
            sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                ls.Remove(sdr[2].ToString());
            }
            foreach (string s in ls)
            {
                DropDownList1.Items.Add(s);
            }
        }

        protected void btnThumb_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

            con.Open();
            string fileName = "FingerImage.bmp";
            string newfilename1 = "Finger" + ".bmp";
            string appPath1 = AppDomain.CurrentDomain.BaseDirectory + @"TempThumb\";
            string appPath2 = AppDomain.CurrentDomain.BaseDirectory + @"Thumb\";
            string sourceFile = System.IO.Path.Combine(appPath1, fileName);
            string destFile = System.IO.Path.Combine(appPath2, newfilename1);
            System.IO.File.Copy(sourceFile, destFile, true);
            string thumb_impression1 = "~/Thumb/" + newfilename1;
            DateTime dateTimeVariable = DateTime.Now;
            string date = dateTimeVariable.ToString("yyyy-MM-dd H:mm:ss");
            byte[] bytearray1 = Encoding.ASCII.GetBytes(thumb_impression1);
            SqlCommand cmd = new SqlCommand("insert into Thumb values('" + txthtno.Text + "','" + DropDownList1.SelectedItem.Text + "','" + thumb_impression1 + "','" + date + "',@Fingdata1,'Pending') ", con);

            cmd.Parameters.Add("@Fingdata1", SqlDbType.Binary).Value = bytearray1;

            int res = cmd.ExecuteNonQuery();
            if (res > 0)
            {
                ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Added Successfully')</script>");
            }
        }

        protected void btnTakeThumb_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

            con.Open();

            btnThumb.Visible = true;
            SqlCommand cmd = new SqlCommand("Update Temp set pos='0'", con);
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                Process p = new Process();
                p.StartInfo.FileName = @"C:\Users\user\Desktop\Windows\\setup.exe";//change the path projct name
                p.Start();
            }
        }
    }
}