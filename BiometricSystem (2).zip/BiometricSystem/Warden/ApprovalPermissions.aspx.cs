﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BiometricSystem.Warden
{
    public partial class ApprovalPermissions : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);

        protected void Page_Load(object sender, EventArgs e)
        {
            ApprovePermissions();
        }
        private void ApprovePermissions()
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("select Student.HallTicketNo,Student.Name,Student.MobileNo,Thumb.Trelation,Thumb.Thumb,Thumb.Date,Thumb.Status from Student inner join Thumb on Student.HallTicketNo=Thumb.HallTicketNo where Thumb.Status='Accepted'", con);
            SqlDataAdapter sdr = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sdr.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
    }
}