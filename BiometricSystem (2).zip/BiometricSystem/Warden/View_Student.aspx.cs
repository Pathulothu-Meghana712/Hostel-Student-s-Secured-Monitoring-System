﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BiometricSystem.WARDEN
{
    public partial class ViewStudent : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindStudents();
            }
        }

        private void BindStudents()
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("Select HallTicketNo,Name,EmailId,MobileNo,Gender,FName,FMobileNo ,Branch,Year,Semester, Address,Photo from Student", con);
            SqlDataAdapter sdr = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sdr.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }

        protected void txtsearch_TextChanged(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Student where HallTicketNo like '" + txtsearch.Text + "' + '%' ", con);
            SqlDataAdapter sdr = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sdr.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            Label htno = (Label)GridView1.Rows[e.RowIndex].FindControl("Label1");
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from  Student where HallTicketNo='" + htno.Text + "'";
            cmd.Connection = con;
            int i = cmd.ExecuteNonQuery();
            con.Close();
            BindStudents();
            if (i > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('OneRecord Deleted')", true);
            }

        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            BindStudents();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            string image = null;
           
                FileUpload f = (FileUpload)GridView1.Rows[e.RowIndex].FindControl("FileUpload1");
                if (f.HasFile)
                {
                    image = "../Images/" + f.FileName;
                    f.PostedFile.SaveAs(Server.MapPath(image));
                }
                else
                {
                    Image i = (Image)GridView1.Rows[e.RowIndex].FindControl("image");
                    image = i.ImageUrl;
                }


                TextBox name = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Textbox2");
                TextBox email = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Textbox3");
                TextBox mobile = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Textbox4");
                TextBox gender = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Textbox5");
                TextBox fname = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Textbox6");
                TextBox fmobile = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Textbox7");
                TextBox branch = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Textbox8");
                TextBox year = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Textbox9");
                TextBox sem = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Textbox10");
                TextBox address = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Textbox11");
                Label htno = (Label)GridView1.Rows[e.RowIndex].FindControl("Label1");
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update Student set Name='" + name.Text + "',EmailId='" + email.Text + "',MobileNo='" + mobile.Text + "',Gender='" + gender.Text + "',FName='" + fname.Text + "',FMobileNo='" + fmobile.Text + "',Branch='" + branch.Text + "',Year='" + year.Text + "',Semester='" + sem.Text + "',Address='" + address.Text + "',Photo='" + image + "' where HallTicketNo='" + htno.Text + "'";
                cmd.Connection = con;
                int res = cmd.ExecuteNonQuery();
                con.Close();
                GridView1.EditIndex = -1;
                BindStudents();
                if (res > 0)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Update Successfully Completed')", true);

                }
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditRowStyle.ForeColor = System.Drawing.Color.Blue;
            GridView1.EditIndex = e.NewEditIndex;
            BindStudents();
        }

       
           
        protected void btnPermission_Click(object sender, EventArgs e)
        {
            LinkButton btnEdit = (LinkButton)sender;
            GridViewRow Grow = (GridViewRow)btnEdit.NamingContainer;
            Label htno = (Label)Grow.FindControl("Label1");
            Session["htno"] = htno.Text;
            Response.Redirect("ViewPermission.aspx");
        }

        protected void btnThumb_Click(object sender, EventArgs e)
        {
            LinkButton btnEdit = (LinkButton)sender;
            GridViewRow Grow = (GridViewRow)btnEdit.NamingContainer;
            Label htno = (Label)Grow.FindControl("Label1");
            Session["htno"] = htno.Text;
            Response.Redirect("Permissions.aspx");
        }
    }
}