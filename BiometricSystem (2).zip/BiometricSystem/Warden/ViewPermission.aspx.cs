﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BiometricSystem.Warden
{
    public partial class VewPermission : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            BindThumbData();
        }
        private void BindThumbData()
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("select Student.HallTicketNo,Student.Name,Student.MobileNo,Thumb.Trelation,Thumb.Thumb,Thumb.Date from Student inner join Thumb on Student.HallTicketNo=Thumb.HallTicketNo where Student.HallTicketNo='" + Session["htno"].ToString() + "'", con);
            SqlDataAdapter sdr = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sdr.Fill(ds);
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }

        protected void btnGivePermission_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            testimage.ImageUrl = "~/TempThumb/FingerImage.bmp";
        }

        protected void AcceptePermission_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();

            }
            con.Open();
            LinkButton btnEdit = (LinkButton)sender;
            GridViewRow Grow = (GridViewRow)btnEdit.NamingContainer;
            Label htno = (Label)Grow.FindControl("Label1");
            Session["htno"] = htno.Text;
            SqlCommand cd = new SqlCommand("update windows set HallTicketNo='" + htno.Text + "'",con);
            int i= cd.ExecuteNonQuery();
            if (i > 0)
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
                con.Open();
                SqlCommand cmd1 = new SqlCommand("Update Temp set pos='1'", con);
                int i1 = cmd1.ExecuteNonQuery();
                if (i1 > 0)
                {
                    Process p = new Process();
                    p.StartInfo.FileName = @"C:\Users\user\Desktop\Windows\\setup.exe";//change the path projct name
                    p.Start();
                }
            }
        }
       


        protected void btnverity_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
                con.Open();
                SqlCommand cmd = new SqlCommand("Update Temp set pos='m'", con);
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    Process p = new Process();
                    p.StartInfo.FileName = @"C:\Users\user\Desktop\Windows\\setup.exe";//change the path projct name
                    p.Start();
                }
                Status();

            }
        }
        private void Status()
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }

            con.Open();
            SqlCommand cmd1 = new SqlCommand("update Student set Status = 'Accepted' where HallTicketNo = '" + Session["htno"].ToString() + "'", con);
            int i = cmd1.ExecuteNonQuery();
            if (i > 0)
            {

            }
        }



    }
}