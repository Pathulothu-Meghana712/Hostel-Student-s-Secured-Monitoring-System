﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BiometricSystem.WARDEN
{
    public partial class AddStudent : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ConnectionString);

        protected void Page_Load(object sender, EventArgs e)
        {

        }

      
        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            if (FileUpload1.HasFile)
            {
                string image = "../Images/" + FileUpload1.FileName;
                FileUpload1.PostedFile.SaveAs(Server.MapPath(image));


                SqlCommand cmd = new SqlCommand("insert into Student values('" + txtsht.Text + "','" + txtname.Text + "','" + txtemailid.Text + "','" + txtmobile.Text + "','" + rbgender.SelectedItem.Text + "','" + txtfname.Text + "','" + txtfmobile.Text + "','" + ddlBranch.SelectedItem.Text + "','" + ddlYear.SelectedItem.Text + "','" + ddlSem.SelectedItem.Text + "','" + txtaddr.Text + "','" + image + "','Pending') ", con);
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Student Added SuccessFully')</script>");
                    txtsht.Text = txtname.Text= txtmobile.Text = txtemailid.Text = txtfname.Text = txtfmobile.Text = txtaddr.Text = "";
                    ddlBranch.ClearSelection();
                    ddlYear.ClearSelection();
                    ddlSem.ClearSelection();
                    rbgender.ClearSelection();
                }
                else
                {
                    ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Failed')</script>");

                }
            }
        }
    }
}